package com.usermanagement.model;

public class User {
	protected int id;
	protected String name;
	protected String email;
	protected String dob;
	protected int mob;
	
	public User() {
	}

	public User(int id, String name, String email, String dob, int mob) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.dob = dob;
		this.mob = mob;
	}

	public User(String name, String email, String dob, int mob) {
		super();
		this.name = name;
		this.email = email;
		this.dob = dob;
		this.mob = mob;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public int getMob() {
		return mob;
	}

	public void setMob(int mob) {
		this.mob = mob;
	}
}